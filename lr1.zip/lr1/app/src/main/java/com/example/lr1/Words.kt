package com.example.lr1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Words {

    var List: MutableList<String> = mutableListOf()

    fun wordsString (word: String) : MutableList<String> {

        for (element in word) if (word[0] == word[word.length-1]) {
            List.add(word)
        }
        return List
    }
}


